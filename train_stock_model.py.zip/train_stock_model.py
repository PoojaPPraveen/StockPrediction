import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_absolute_error, r2_score
import joblib
import torch
import torch.nn as nn
import torch.optim as optim
from tqdm import tqdm

# Function to load and preprocess the dataset
def load_and_preprocess_data(file_path):
    df = pd.read_csv('nyse.csv')
    df['Moving Avg 10'] = df['close'].rolling(window=10).mean()
    df['Moving Avg 50'] = df['close'].rolling(window=50).mean()
    df['RSI'] = 100 - (100 / (1 + (df['close'].diff().clip(lower=0).rolling(window=14).mean() /
                                   df['close'].diff().clip(upper=0).rolling(window=14).mean())))
    df['MACD'] = df['close'].ewm(span=12, adjust=False).mean() - df['close'].ewm(span=26, adjust=False).mean()
    df['Daily Return'] = df['close'].pct_change()
    df['next_close'] = df['close'].shift(-1)
    df.dropna(inplace=True)
    return df

# Function to prepare features and target
def prepare_features_target(df):
    features = ['Moving Avg 10', 'Moving Avg 50', 'RSI', 'MACD', 'Daily Return']
    X = df[features].copy()
    y = df['next_close'].copy()
    X.replace([np.inf, -np.inf], np.nan, inplace=True)
    y.replace([np.inf, -np.inf], np.nan, inplace=True)
    X.dropna(inplace=True)
    y = y.loc[X.index]
    return X, y

# Function to define the neural network model
class StockPredictor(nn.Module):
    def __init__(self, input_size):
        super(StockPredictor, self).__init__()
        self.fc1 = nn.Linear(input_size, 128)
        self.fc2 = nn.Linear(128, 64)
        self.fc3 = nn.Linear(64, 32)
        self.fc4 = nn.Linear(32, 1)

    def forward(self, x):
        x = torch.relu(self.fc1(x))
        x = torch.relu(self.fc2(x))
        x = torch.relu(self.fc3(x))
        x = self.fc4(x)
        return x

# Function to train the model
def train_model(X_train, y_train, input_size, epochs=10, batch_size=64):
    model = StockPredictor(input_size)
    criterion = nn.MSELoss()
    optimizer = optim.Adam(model.parameters(), lr=0.001)
    X_train_tensor = torch.tensor(X_train, dtype=torch.float32)
    y_train_tensor = torch.tensor(y_train.values, dtype=torch.float32).view(-1, 1)
    n_batches = int(len(X_train) / batch_size)
    
    for epoch in tqdm(range(epochs), desc="Training Epochs"):
        model.train()
        epoch_loss = 0
        for i in range(n_batches):
            start_idx = i * batch_size
            end_idx = start_idx + batch_size
            X_batch = X_train_tensor[start_idx:end_idx]
            y_batch = y_train_tensor[start_idx:end_idx]
            optimizer.zero_grad()
            outputs = model(X_batch)
            loss = criterion(outputs, y_batch)
            loss.backward()
            optimizer.step()
            epoch_loss += loss.item()
        print(f'Epoch [{epoch+1}/{epochs}], Loss: {epoch_loss/n_batches:.4f}')
    return model

# Main script
if __name__ == "__main__":
    df = load_and_preprocess_data('path_to_your_dataset.csv')
    X, y = prepare_features_target(df)
    
    if np.any(np.isnan(X)) or np.any(np.isnan(y)):
        raise ValueError("X or y contains NaN values after cleaning")
    
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=0)
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)
    
    model = train_model(X_train_scaled, y_train, input_size=len(X.columns), epochs=10, batch_size=64)
    
    torch.save(model.state_dict(), 'stock_model.pth')
    joblib.dump(scaler, 'scaler.pkl')
    
    model.eval()
    X_test_tensor = torch.tensor(X_test_scaled, dtype=torch.float32)
    y_test_tensor = torch.tensor(y_test.values, dtype=torch.float32).view(-1, 1)
    with torch.no_grad():
        predictions = model(X_test_tensor).numpy()
        mae = mean_absolute_error(y_test, predictions)
        r2 = r2_score(y_test, predictions)
    
    print(f"Model and scaler saved successfully.")
    print(f"Mean Absolute Error: {mae}")
    print(f"R^2 Score: {r2}")
